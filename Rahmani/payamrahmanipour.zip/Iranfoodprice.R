## ----setup, include=FALSE-----------------------------------------------------
library("knitr")
knit_hooks$set(purl = hook_purl)

## ----1, include=FALSE---------------------------------------------------------
setwd("C:/Users/payam/Desktop/FinalRProject")

## ----2, message=FALSE, warning=FALSE------------------------------------------
library(tidyverse)

## ----3, message=FALSE, warning=FALSE------------------------------------------
library(ggplot2)
library(hms)
library(lubridate)

## ----4------------------------------------------------------------------------
foodprices <- read.csv((url("https://data.humdata.org/dataset/6df76343-1bd9-488a-af3c-1e5aec3fc78c/resource/987b0f53-5b55-4ed8-868a-ea285f0f0307/download/wfp_food_prices_irn.csv")))

## ----5------------------------------------------------------------------------
str(foodprices)

## ----7------------------------------------------------------------------------
foodprices <- foodprices[-c(1), ]

## ----8------------------------------------------------------------------------
# Printing amount of missing values for each of the i = [1:14]features
for (i in 1:14) {
  message(sum(is.na(foodprices[i]))," missing values in column ", i)
}

## ----9------------------------------------------------------------------------
foodprices$price <- as.integer(foodprices$price)
foodprices[foodprices==0] <- NA
foodprices <- foodprices[complete.cases(foodprices),]

## ----10, message=FALSE, warning=FALSE, paged.print=FALSE----------------------
library(dplyr)

## ----11-----------------------------------------------------------------------
# Printing distinct values for each of the i = [1:12]features
for (i in 1:14) {
  message(n_distinct(foodprices[i])," distinct values in column ", i)
}

## ----12-----------------------------------------------------------------------
# Declare trim function to delete leading and trailing white spaces
trim <- function (x) gsub("^\\s+|\\s+$", "", x)
# Trimming column $category and $commodity
foodprices$category <- trim(foodprices$category)
foodprices$commodity <- trim(foodprices$commodity)

## ----13, echo=TRUE------------------------------------------------------------
message(n_distinct(foodprices[7]),
        " distinct values in column category after trimming")
message(n_distinct(foodprices[8]),
        " distinct values in column comodity after trimming")

## ----14-----------------------------------------------------------------------
# Converting all character of data frame to lowercase
foodprices <- mutate_all(foodprices, .funs=tolower)

## ----15, echo=TRUE------------------------------------------------------------
message(n_distinct(foodprices[7]),
        " distinct values in column category after conversion to lowercase")
message(n_distinct(foodprices[8]),
        " distinct values in column comodity after conversion to lowercase")

## ----16, echo=TRUE------------------------------------------------------------
message(n_distinct(foodprices[foodprices$date<"2022-01-01",7]),
        " distinct values in column category until 2022")
message(n_distinct(foodprices[foodprices$date<"2022-01-01",8]),
        " distinct values in column comodity until 2022")

## ----17-----------------------------------------------------------------------
foodprices <- foodprices[, -c(2:6,10:12)]

## ----18-----------------------------------------------------------------------
unique(foodprices[foodprices$date<"2022-01-01",3])

## ----19-----------------------------------------------------------------------
unique(foodprices[foodprices$date<"2022-01-01",4])

## ----20-----------------------------------------------------------------------
library(stringr)
foodprices[foodprices$date <"2022-01-01",] %>% 
  group_by(item = str_extract(commodity,"^\\w+(?=\\s*)")) %>% 
  summarise(isUnitSame = n_distinct(str_extract(unit,"[a-z]+$"))==1)

## ----21-----------------------------------------------------------------------
# Changing data types
foodprices$date <- as.Date(foodprices$date)
foodprices$category <- as.factor(foodprices$category)
foodprices$commodity <- as.factor(foodprices$commodity)
foodprices$unit <- as.factor(foodprices$unit)
foodprices$price <- as.integer(foodprices$price)
foodprices$usdprice <- as.numeric(foodprices$usdprice)

## ----22-----------------------------------------------------------------------
### Create $day and $month and $year
foodprices$day <- weekdays(as.Date(foodprices$date))
foodprices$month <- months(as.Date(foodprices$date))
foodprices$year <- year(as.Date(foodprices$date))

## ----23-----------------------------------------------------------------------
# Convert to factor and integer
foodprices$day <- as.factor(foodprices$day)
foodprices$month <- as.factor(foodprices$month)
foodprices$year <- as.integer(foodprices$year)

## ----24, echo=FALSE-----------------------------------------------------------
message("Minimum Price:",min(foodprices[foodprices$date<"2022-01-01",5]))

message("Average Price:",mean(foodprices[foodprices$date<"2022-01-01",5]))

message("Maximum Price:",max(foodprices[foodprices$date<"2022-01-01",5]))

## ----25, echo=FALSE-----------------------------------------------------------
foodpricesmin <- foodprices[foodprices$date < "2022-01-01",]  %>%
  group_by(commodity) %>%
  summarise(min(price))
kable(foodpricesmin, caption = "Min Price For Each Item")

## ----26-----------------------------------------------------------------------
foodprices %>% 
  filter_all(any_vars(. %in% c(2691,6085,29910)))

## ----27-----------------------------------------------------------------------
foodprices['price'][foodprices['price'] == 2691] <- 269100
foodprices['price'][foodprices['price'] == 6085] <- 244950
foodprices['price'][foodprices['price'] == 29910] <- 299100
foodprices['usdprice'][foodprices['usdprice'] == 0.1449] <- 6
foodprices['usdprice'][foodprices['usdprice'] == 0.7121] <- 7
foodprices['usdprice'][foodprices['usdprice'] == 0.0641] <- 4

## ----28-----------------------------------------------------------------------
summary(foodprices)

## ----29, echo=FALSE, warning=FALSE--------------------------------------------
kable(foodprices[1:10,], caption = "Food Prices Table")

## ----30, message=FALSE--------------------------------------------------------
# New table for IRR Price group by category
foodprices_IRR <- foodprices[foodprices$date < "2022-01-01",] %>%
  group_by(date, category)%>%
  summarise(price)

## ----31, message=FALSE, warning=FALSE-----------------------------------------
g1 <- ggplot(data = foodprices_IRR, aes(x = date, y = price, color = category))+
  geom_line(linewidth=1) 
g1+labs(title="Change Of Food Prices From 2012 To 2022 ",y="Price IRR",x="Year",
          caption="Fig.1:Food Prices Over Time") +
  scale_y_continuous(breaks=seq(10000, 700000, 100000)) +
  scale_x_date(date_labels = "%b %y")+
  geom_vline(xintercept=ymd("2018-03-08") , linetype="dotted", color = "blue") +
  annotate(geom = "text", 
           x = ymd("2017-12-01") , y = 410000 ,label = "Reinstated Sanctions" ,
           angle=90 )

## ----32, message=FALSE--------------------------------------------------------
# New table for USD Price group by category
foodprices_USD <- foodprices[foodprices$date < "2022-01-01",] %>%
  group_by(date, category)%>%
  summarise(usdprice)

## ----33, message=FALSE, warning=FALSE-----------------------------------------
g1 <- ggplot(data = foodprices_USD, aes(x = date, y = usdprice, color = category))+ 
  geom_line(linewidth=1) 
g1 + labs(title="Change Of Food USDPrices From 2012 To 2022 ",
          y="Price USD", x="Year", caption="Fig.2:Food USDPrices Over Time") + 
  scale_y_continuous(breaks=seq(1, 20, 1)) + scale_x_date(date_labels = "%b %y")+ geom_vline(xintercept=ymd("2018-03-08") , linetype="dotted", color = "blue") +
  annotate(geom = "text", x = ymd("2017-12-01") , y = 10 ,
           label = "Reinstated Sanctions" , angle=90 )

## ----34, message=FALSE, warning=FALSE-----------------------------------------
foodprices_IRR$lnprice <- log(foodprices_IRR$price)
g1 <- ggplot(data = foodprices_IRR, aes(x = date, y = lnprice, color = category)) +
  geom_line(linewidth=1)
g1 + labs(title="Change Of Log Food Prices From 2012 To 2022 ",
          y="Log Price IRR", x="Year",
          caption="Fig.3:Log Food Prices Over Time") +
  scale_y_continuous(breaks=seq(8, 14, 1)) + scale_x_date(date_labels = "%b %y")+ 
  geom_vline(xintercept=ymd("2018-03-08") , linetype="dotted", color = "blue")+
  annotate(geom = "text", x = ymd("2017-12-01") ,
           y = 12 ,label = "Reinstated Sanctions" , angle=90 )

## ----35, message=FALSE, warning=FALSE-----------------------------------------

foodprices_USD$lnusdprice <- log(foodprices_USD$usdprice)
g1 <- ggplot(data = foodprices_USD,
             aes(x = date, y = lnusdprice, color = category)) +
  geom_line(linewidth=1) 
g1 + labs(title="Change Of Log Food USDPrices From 2012 To 2022 ",
          y="Log Price USD", x="Year", 
          caption="Fig.4:Log Food USDPrices Over Time") +
  scale_y_continuous(breaks=seq(-0.2, 2.5, 0.3))  + 
  scale_x_date(date_labels = "%b %y")+ 
  geom_vline(xintercept=ymd("2018-03-08") , linetype="dotted", color = "blue") +
  annotate(geom = "text", x = ymd("2017-12-01") , y = 2 ,
           label = "Reinstated Sanctions" , angle=90 )

## ----36, message=FALSE--------------------------------------------------------
# New table for Log IRR Price group by category cereals and tubers
foodprices_cereals <- foodprices_IRR[foodprices_IRR$category ==
                                       "cereals and tubers",]%>%
  group_by(date, category)%>%
  summarise(lnprice) 

## ----37, message=FALSE--------------------------------------------------------
# New table for Log IRR Price group by category meat, fish and eggs
foodprices_meat <- foodprices_IRR[foodprices_IRR$category ==
                                    "meat, fish and eggs",]%>%
  group_by(date, category)%>%
  summarise(lnprice)

## ----38, message=FALSE--------------------------------------------------------
# New table for Log IRR Price group by category miscellaneous food
foodprices_miscellaneous <- foodprices_IRR[foodprices_IRR$category ==
                                             "miscellaneous food",]%>%
  group_by(date, category)%>%
  summarise(lnprice)

## ----39, message=FALSE--------------------------------------------------------
# New table for Log IRR Price group by category oil and fats
foodprices_oil <- foodprices_IRR[foodprices_IRR$category == 
                                   "oil and fats",]%>%
  group_by(date, category)%>%
  summarise(lnprice) 

## ----40, message=FALSE--------------------------------------------------------
# New table for Log IRR Price group by category pulses and nuts
foodprices_pulses <- foodprices_IRR[foodprices_IRR$category == 
                                      "pulses and nuts",]%>%
  group_by(date, category)%>%
  summarise(lnprice) 

## ----42, message=FALSE--------------------------------------------------------
foodprices_cereals <- foodprices_cereals %>%
  group_by( category ) %>%
  mutate(Rate_percent  =  ((lnprice - lag(lnprice)) / lag(lnprice))*100)

## ----43,warning=FALSE---------------------------------------------------------
ggplot(foodprices_cereals) +
   geom_line(linewidth=1) +
   aes(x = date , y = Rate_percent , color = category) + 
   geom_line() + 
   scale_y_continuous(breaks=seq(-7, 7, 0.5)) +
   labs(title="Growth rate for cereals From 2012 To 2022 ", 
        caption="Fig.5:Growth rate for cereals")
   

## ----44, message=FALSE--------------------------------------------------------
foodprices_meat <- foodprices_meat %>%
  group_by( category ) %>%
  mutate(Rate_percent  =  ((lnprice - lag(lnprice)) / lag(lnprice))*100)

## ----45,warning=FALSE---------------------------------------------------------
ggplot(foodprices_meat) +
   geom_line(linewidth=1) +
   aes(x = date , y = Rate_percent , color = category) + 
   geom_line() + 
   scale_y_continuous(breaks=seq(-7, 7, 0.5)) +
   labs(title="Growth rate for meat From 2012 To 2022 ", 
        caption="Fig.6:Growth rate for Meat")
   

## ----46, message=FALSE--------------------------------------------------------
foodprices_miscellaneous <- foodprices_miscellaneous %>%
  group_by( category ) %>%
  mutate(Rate_percent  =  ((lnprice - lag(lnprice)) / lag(lnprice))*100)

## ----47,warning=FALSE---------------------------------------------------------
ggplot(foodprices_miscellaneous) +
   geom_line(linewidth=1) +
   aes(x = date , y = Rate_percent , color = category) + 
   geom_line() + 
   scale_y_continuous(breaks=seq(-7, 8, 0.5)) +
   labs(title="Growth rate for miscellaneous From 2012 To 2022 ", 
        caption="Fig.7:Growth rate for miscellaneous")
   

## ----48, message=FALSE--------------------------------------------------------
foodprices_oil <- foodprices_oil %>%
  group_by( category ) %>%
  mutate(Rate_percent  =  ((lnprice - lag(lnprice)) / lag(lnprice))*100)

## ----49,warning=FALSE---------------------------------------------------------
ggplot(foodprices_oil) +
   geom_line(linewidth=1) +
   aes(x = date , y = Rate_percent , color = category) + 
   geom_line() + 
   scale_y_continuous(breaks=seq(-7, 8, 0.5)) +
   labs(title="Growth rate for oil and fat From 2012 To 2022 ",
        caption="Fig.8:Growth rate for oil and fat")
   

## ----50, message=FALSE--------------------------------------------------------
foodprices_pulses <- foodprices_pulses %>%
  group_by( category ) %>%
  mutate(Rate_percent  =  ((lnprice - lag(lnprice)) / lag(lnprice))*100)

## ----51,warning=FALSE---------------------------------------------------------
ggplot(foodprices_pulses) +
   geom_line(linewidth=1) +
   aes(x = date , y = Rate_percent , color = category) + 
   geom_line() + 
   scale_y_continuous(breaks=seq(-7, 12, 1)) +
   labs(title="Growth rate for pulses and nuts From 2012 To 2022 ", 
        caption="Fig.9:Growth rate for pulses and nuts")
   

